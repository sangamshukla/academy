<?php

declare(strict_types=1);

namespace MeiliSearch\Endpoints;

use MeiliSearch\Contracts\Endpoint;

class Stats extends Endpoint
{
    protected const PATH = '/stats';
}
