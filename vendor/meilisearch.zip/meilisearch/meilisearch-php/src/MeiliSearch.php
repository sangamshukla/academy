<?php

declare(strict_types=1);

namespace MeiliSearch;

class MeiliSearch
{
    public const VERSION = '0.18.3';
}
